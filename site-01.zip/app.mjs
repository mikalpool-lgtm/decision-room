import {resolveTurn} from './engine.mjs';
import {ArticleReader} from './reader.mjs';
import {activitySections, mountActivity, recordActivity} from './activity.mjs';
import {setupIntro} from './intro.mjs';
const staticHosting=document.documentElement.dataset.hosting==='static';
const main=document.getElementById('main'),help=document.getElementById('help'),status=document.getElementById('status');
const esc=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[ch]);
const accents={Intro:'#abb29f',People:'#cadb7a',Model:'#ebc1bf',AI:'#8bcddc'};
const themes={'媒體投資':'#cadb7a','品牌內容':'#ebc1bf','研究判斷':'#8bcddc','組織與 AI':'#8bcddc','顧客體驗':'#9ac9c4'};
const icons={chat:'<path d="M4 4.5h16v12H10l-5 4v-4H4z"/><path d="M8 9h8M8 12h5"/>',search:'<circle cx="10" cy="10" r="6.5"/><path d="m15 15 5 5"/>',replay:'<path d="M4 10a8 8 0 1 1 2 8M4 4v6h6"/>'};
const icon=name=>`<svg class="glyph" viewBox="0 0 24 24" aria-hidden="true">${icons[name]}</svg>`;
const getData=async name=>{const r=await fetch(`./data/${name}.json`);if(!r.ok)throw Error(name);return r.json()};
let cards=[],sources=[],history=[],reader=null,selection=null,route='',cat='全部',chapter='全部',query='',working=false,draft='',accessCode='',notice='',version=0,loaded=false;
let refreshActivity=null;
let focusQuestionOnLoad=false;
const card=id=>cards.find(c=>c.id===id),article=id=>sources.find(s=>s.id===id);
const live=()=>!staticHosting&&Boolean(accessCode);
function say(text){status.textContent=text}
function setRoute(name){if(location.hash.slice(1)===name)render();else location.hash=name}
function openPage(){
 if(working){version++;working=false}
 const requested=location.hash.slice(1);route=['questions','library','talk'].includes(requested)?requested:'home';
 if(route==='talk'&&!history.length&&!working)route='home';
 query='';selection=null;render();window.scrollTo(0,0);
 if(focusQuestionOnLoad||requested==='ask'){
   focusQuestionOnLoad=false;
   if(route==='home')document.getElementById('clientInput')?.focus({preventScroll:true});
 }
}
function entry(isChat=false){
 const placeholder=isChat?'繼續追問，或補充客戶的情境……':'貼上客戶的原話，或寫下你想討論的問題……';
 return `<form class="entry" id="entry"><textarea id="clientInput" required maxlength="2000" rows="2" aria-label="${placeholder}" placeholder="${placeholder}">${esc(draft)}</textarea>
 ${staticHosting?'':'<div class="share-choice"><label><input id="share-question" type="checkbox" aria-describedby="share-hint"> 同意將這句提問原文刊在本站首頁的雙週輯</label><p id="share-hint">分享前請先移除客戶名稱、人名與未公開資訊。</p></div>'}
 <div class="formline"><span class="mode-line">${live()?'AI 對話':'專刊導讀'}</span><button class="primary" type="submit" ${working?'disabled':''}>${icon('chat')}${working?'整理中…':isChat?'繼續討論':'開始討論'}</button></div></form>`;
}
function questionCard(c){return `<button type="button" class="qcard" data-card="${c.id}" style="--accent:${themes[c.category]}"><span class="caption">${esc(c.category)}</span><strong>${esc(c.question)}</strong></button>`}
function home(){
 const selections=['p20','p09','p15'].map(card).filter(Boolean);
 const flowerImage=document.getElementById('story-intro')?.open?'./assets/sunflower-front.png':'./assets/sunflower-turn.webp';
 return `<section class="hero"><div class="hero-copy"><p class="kicker">客戶對話室</p><h1><span>剛剛客戶</span><span>怎麼說？</span></h1><p>把原話交給向日葵，一起找出怎麼接話、往哪裡追問。</p>${entry()}</div><figure class="hero-art"><picture><source media="(prefers-reduced-motion: reduce)" srcset="./assets/sunflower-front.png"><img id="flower" src="${flowerImage}" alt="專刊素描向日葵從右側轉向你" width="520" height="776" fetchpriority="high"></picture><figcaption><button type="button" class="quiet-btn" data-replay>${icon('replay')}重播向日葵</button></figcaption></figure></section>
 ${staticHosting?'':activitySections()}
 <section class="suggestions"><div class="sectionhead"><h2>從專刊情境開始</h2><a class="textbtn" href="#questions">全部 ${cards.length} 題</a></div><div class="question-grid">${selections.map(questionCard).join('')}</div></section>`;
}
function filters(kind){
 const items=kind==='questions'?['全部',...new Set(cards.map(c=>c.category))]:['全部',...Object.keys(accents)];
 return `<div class="filters"><label class="search">${icon('search')}<input id="search" type="search" value="${esc(query)}" placeholder="搜尋${kind==='library'?'篇名、作者':'問題或關鍵字'}" aria-label="搜尋${kind==='library'?'篇名、作者':'問題或關鍵字'}"></label>${items.map(x=>`<button data-filter="${esc(x)}" class="chip" aria-pressed="${x===(kind==='questions'?cat:chapter)}">${esc(x)}</button>`).join('')}</div>`;
}
function catalog(kind){
 const books=kind==='library';
 return `<section class="subpage"><div class="subhead"><h1>${books?'專刊文章':'問題庫'}</h1></div>${filters(kind)}<p class="count" id="count" aria-live="polite"></p><div id="bookwrap" ${selection&&books?'class="book-body"':''}><div id="results"></div>${books&&selection?'<aside id="reader"></aside>':''}</div></section>`;
}
function articleCard(s){
 const active=selection?.id===s.id;
 return `<button class="article-row" aria-current="${active}" data-source="${s.id}" data-page="1">
   <img class="cover" alt="" width="480" height="320" loading="lazy" src="./assets/covers/${s.id}.webp">
   <span class="article-info"><span class="chapter" style="--accent:${accents[s.chapter]}">${esc(s.chapter)}</span>
   <strong>${esc(s.title)}</strong><span class="meta">${esc(s.author)}</span></span></button>`;
}
function listResults(){
 const books=route==='library',q=query.trim().toLowerCase(),subset=books?sources.filter(s=>(chapter==='全部'||chapter===s.chapter)&&[s.title,s.author,s.chapter].join(' ').toLowerCase().includes(q)):cards.filter(c=>(cat==='全部'||cat===c.category)&&[c.question,c.category,...c.keywords].join(' ').toLowerCase().includes(q));
 document.querySelector('#count').textContent=books?`共 ${subset.length} 篇文章`:`共 ${subset.length} 個問題`;
 document.querySelector('#results').innerHTML=!subset.length?'<p class="empty">找不到相符內容。試試另一個關鍵字，或切換分類。</p>':books?`<div class="library-list">${subset.map(articleCard).join('')}</div>`:`<div class="question-grid">${subset.map(questionCard).join('')}</div>`;
}
function citation(ref){
 return `<button class="cite" style="--accent:${accents[ref.chapter]||accents.Intro}" data-source="${esc(ref.id)}" data-page="${ref.page??1}">${esc(ref.title)}<span>${esc(ref.label)}${ref.page===null?' · 頁碼未確認':''}</span></button>`;
}
function answer(t){
 const showAsk=t.ask?.length,showRefs=t.refs?.length;
 return `<article class="turn"><h2 class="clientq">${esc(t.question)}</h2>${t.receipt ? `<p class="share-receipt" aria-live="polite" data-receipt="${esc(t.receipt.event.eventId)}">${receiptBody(t.receipt)}</p>` : ''}<div class="byline"><img src="./assets/sunflower-mark.png" alt="">向日葵 · ${t.kind==='live'?'AI 對話':'專刊導讀'}</div><h3>${['clarify','unsupported'].includes(t.kind)?'先釐清問題':t.kind==='followup'?'接著聊':'可以這樣接'}</h3><p class="say">${esc(t.reply)}</p>${showAsk?`<h3>可以問客戶</h3><ul>${t.ask.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}${t.insight?`<h3>專刊怎麼看</h3><p>${esc(t.insight)}</p>`:''}${t.limit?`<details><summary>引用時要留意</summary><p>${esc(t.limit)}</p></details>`:''}${showRefs?`<h3>對照原文</h3>${t.refs.map(citation).join('')}`:''}</article>`;
}
function conversation(){
 const last=history.at(-1);
 return `<section class="workspace"><div class="rowhead"><h1>客戶對話室</h1><button data-new class="textbtn">新對話</button></div><div class="workspace-body ${selection?'':'no-reader'}"><div id="chat"><div class="history-tools">${history.length>1?`<details><summary>前 ${history.length-1} 輪對話</summary>${history.slice(0,-1).map(answer).join('')}</details>`:''}</div>${last?answer(last):''}${notice?`<p role="status" class="error">${esc(notice)}</p>`:''}${last?.cardId?`<div class="followups">${['有案例嗎？','下一步怎麼做？','證據有哪些限制？'].map(t=>`<button data-follow="${esc(t)}">${esc(t)}</button>`).join('')}</div>`:''}${entry(true)}${last?.related?.length?`<details class="history-tools" ${last.cardId?'':'open'}><summary>其他討論方向</summary><div class="followups">${last.related.map(id=>card(id)).filter(Boolean).map(c=>`<button data-card="${c.id}">${esc(c.question)}</button>`).join('')}</div></details>`:''}</div>${selection?'<aside id="reader"></aside>':''}</div></section>`;
}
function mountReader(){
 const host=document.querySelector('#reader'),sel=selection;if(!host||!sel||!article(sel.id))return;
 function markPage(n){
   sel.page=n;
   for(const button of document.querySelectorAll('.cite')){
     if(button.dataset.source===sel.id&&Number(button.dataset.page)===n)button.setAttribute('aria-current','page');
     else button.removeAttribute('aria-current');
   }
 }
 reader=new ArticleReader(host,article(sel.id),sel.page,()=>{
   const {id,originPage}=sel;
   selection=null;render();
   document.querySelector(`[data-source="${id}"][data-page="${originPage||1}"]`)?.focus({preventScroll:true});
 },{onPage:markPage,modal:sel.clicked});
 if(sel.clicked)host.querySelector('[data-reader="close"]')?.focus({preventScroll:true});
}
function render(){
 reader?.destroy();reader=null;
 refreshActivity=null;
 document.querySelectorAll('[data-nav]').forEach(a=>{if(a.dataset.nav===(route==='talk'?'home':route))a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
 main.innerHTML=route==='home'?home():route==='talk'?conversation():catalog(route);
 if(route==='questions'||route==='library')listResults();
 if(route==='home'&&!staticHosting)refreshActivity=mountActivity(document.querySelector('#activity'),card);
 if(route==='home'&&matchMedia('(prefers-reduced-motion: reduce)').matches)document.querySelector('[data-replay]').hidden=true;
 mountReader();
}
function receiptBody(receipt){
 if(receipt.state==='saved')return '已收到你的原文，將於本期結束後刊在首頁。';
 if(receipt.state==='failed')return `還無法確認這句原文是否收錄。 <button type="button" class="textbtn" data-retry-share="${esc(receipt.event.eventId)}">再試一次</button>`;
 return '正在送出這句提問原文…';
}

async function saveAsk(receipt){
 receipt.state='pending';
 const container=()=>document.querySelector(`[data-receipt="${receipt.event.eventId}"]`);
 if(container())container().innerHTML=receiptBody(receipt);
 try{
   await recordActivity(receipt.event);
   receipt.state='saved';
   if(refreshActivity)refreshActivity();
 }catch{receipt.state='failed'}
 if(container())container().innerHTML=receiptBody(receipt);
}

async function send(question,cardId,{kind=null,share=false}={}){
 const value=question.trim().slice(0,2000);if(working||!value)return;
 working=true;draft='';notice='';
 const generation=++version,prior=history.slice(-6);
 // Keep the user's first question on screen while obtaining any live response.
 const field=document.querySelector('#clientInput');if(field)field.value=value;
 const btn=document.querySelector('#entry button');if(btn){btn.disabled=true;btn.textContent='整理中…'}
 say('正在查找專刊依據');
 let t=resolveTurn(value,prior,cards,sources,{cardId});
 if(live()){
   try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${accessCode}`},body:JSON.stringify({question:value,cardId,history:prior.map(({question,cardId,reply})=>({question:question.slice(0,750),cardId,reply:reply.slice(0,750)}))}),signal:AbortSignal.timeout(27000)});
     if(!r.ok)throw Error(String(r.status));
     const response=await r.json();if(typeof response.reply!=='string'||!Array.isArray(response.refs))throw Error('format');t=response;
   }catch(e){
     if(generation===version){
       if(e.message==='401'){accessCode='';syncMode();notice='存取碼未通過驗證。這一輪已切回專刊導讀。'}
       else notice='AI 服務目前無法回應，這一輪顯示專刊導讀。';
     }
   }
 }
 let receipt=null;
 const topic=kind==='card'?cardId:t.cardId;
 if(!staticHosting && kind && (topic || share)){
   const sharedText=kind==='typed'&&share ? value : null;
   receipt={event:{eventId:crypto.randomUUID(),kind,cardId:topic||null,sharedText},state:'pending'};
   void saveAsk(receipt);
 }
 if(generation!==version)return;
 history.push({...t,question:value,receipt:receipt?.event.sharedText?receipt:null});working=false;
 const ref=t.refs[0];selection=ref&&!matchMedia('(max-width:690px)').matches?{id:ref.id,page:ref.page||1}:null;
 if(location.hash!=='#talk')window.history.pushState(null,'','#talk');
 route='talk';render();say('已整理回應與原文依據');window.scrollTo(0,0);main.focus({preventScroll:true});
}
main.addEventListener('submit',e=>{
 if(e.target.id!=='entry')return;
 e.preventDefault();
 send(document.querySelector('#clientInput').value,undefined,{kind:'typed',share:document.querySelector('#share-question')?.checked===true});
});
main.addEventListener('keydown',e=>{if(e.target.id==='clientInput'&&e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.keyCode!==229){e.preventDefault();e.target.form.requestSubmit()}});
main.addEventListener('input',e=>{if(e.target.id==='search'){query=e.target.value;listResults()}if(e.target.id==='clientInput')draft=e.target.value});
main.addEventListener('click',e=>{
 const b=e.target.closest('button');if(!b)return;
 if(b.hasAttribute('data-replay')){document.querySelector('#flower').src='./assets/sunflower-turn.webp?replay='+Date.now();return}
 if(b.hasAttribute('data-card')){const c=card(b.dataset.card);if(c)send(c.question,c.id,{kind:'card'});return}
 if(b.hasAttribute('data-real-question')){send(b.querySelector('.quote-text').textContent);return}
 if(b.hasAttribute('data-retry-share')){
   const receipt=history.find(t=>t.receipt?.event.eventId===b.dataset.retryShare)?.receipt;
   if(receipt?.state==='failed')void saveAsk(receipt);
   return;
 }
 if(b.hasAttribute('data-follow')){send(b.dataset.follow);return}
 if(b.hasAttribute('data-filter')){if(route==='questions')cat=b.dataset.filter;else chapter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(el=>el.setAttribute('aria-pressed',String(el===b)));listResults();return}
 if(b.hasAttribute('data-source')){const page=Number(b.dataset.page)||1;selection={id:b.dataset.source,page,originPage:page,clicked:true};render();return}
 if(b.hasAttribute('data-new')){version++;working=false;history=[];selection=null;draft='';notice='';setRoute('home')}
});
document.querySelector('[data-nav="home"]').addEventListener('click',e=>{if(history.length){e.preventDefault();setRoute('talk')}});
document.querySelector('.skip').addEventListener('click',e=>{e.preventDefault();main.focus()});
document.querySelector('#guide').onclick=()=>help.showModal();
document.querySelector('[data-close]').onclick=()=>help.close();
help.addEventListener('click',e=>{if(e.target===help){const r=help.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)help.close()}});
let aiAvailable=false;
function syncMode(){
 document.querySelector('#live-form').hidden=!aiAvailable||live();
 document.querySelector('#disable-live').hidden=!live();
 document.querySelector('#mode-note').textContent=live()?'目前使用團隊 AI 對話。重新整理會清除本頁的對話與存取碼。':'目前使用專刊導讀，提問由瀏覽器比對專刊內容。重新整理會清除本頁對話。';
}
document.querySelector('#activity-guide').hidden=staticHosting;
document.querySelector('#live-form').onsubmit=e=>{e.preventDefault();const i=document.querySelector('#access');if(!aiAvailable||!i.value.trim())return;accessCode=i.value.trim();i.value='';syncMode();help.close();render()};
document.querySelector('#disable-live').onclick=()=>{accessCode='';syncMode();help.close();render()};
window.addEventListener('hashchange',()=>{if(loaded)openPage()});
async function init(){
 main.innerHTML='<p class="subpage">正在翻開專刊…</p>';
 try{[cards,sources]=await Promise.all([getData('cards'),getData('sources')]);loaded=true;openPage()}
 catch{main.innerHTML='<div class="subpage"><h1>專刊尚未載入</h1><p>請確認連線後再試一次。</p><button id="retry" class="primary">重新載入</button></div>';document.querySelector('#retry').onclick=init;return}
 if(!staticHosting){
   try{const r=await fetch('/api/chat',{signal:AbortSignal.timeout(3500)});aiAvailable=r.ok&&(await r.json()).enabled===true}catch{}
 }
 syncMode();
}
setupIntro(enterHome=>{
 const flower=document.getElementById('flower');
 if(flower?.getAttribute('src')==='./assets/sunflower-front.png'&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
   flower.src='./assets/sunflower-turn.webp';
 }
 if(!enterHome)return;
 if(!loaded){focusQuestionOnLoad=true;return}
 if(route!=='home'){
   focusQuestionOnLoad=true;
   setRoute('home');
   return;
 }
 window.scrollTo(0,0);
 document.getElementById('clientInput')?.focus({preventScroll:true});
});
init();
