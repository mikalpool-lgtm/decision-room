const endpoint = '/api/activity';
const escape = value => String(value ?? '').replace(/[&<>"']/g, ch => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
})[ch]);

function displayRange(start, end) {
  const first = start.replaceAll('-', '/');
  const last = (start.slice(0, 4) === end.slice(0, 4) ? end.slice(5) : end).replaceAll('-', '/');
  return first + ' – ' + last;
}

function ranking(rows, findCard) {
  const entries = rows.map(row => ({ card: findCard(row.cardId), count: row.count }))
    .filter(row => row.card && row.count > 0).slice(0, 5);
  if (!entries.length) return '<p class="activity-empty">近 14 天還沒有可列入排行的提問。</p>';
  return '<ol class="popular-list">' + entries.map(({ card, count }) =>
    `<li><button type="button" data-card="${escape(card.id)}"><span>${escape(card.question)}</span><span class="ask-count">${Number(count).toLocaleString('zh-TW')} 次</span></button></li>`
  ).join('') + '</ol>';
}

function sharedQuestion(entry) {
  const times = entry.count > 1 ? `<span class="quote-count">同樣問法出現 ${Number(entry.count).toLocaleString('zh-TW')} 次</span>` : '';
  return `<li><button type="button" data-real-question><span class="quote-text">${escape(entry.text)}</span>${times}</button></li>`;
}

function digest({ issue, issues, nextRelease }) {
  const publicationDate = `<p class="next-issue">下期刊出 <time datetime="${escape(nextRelease)}">${escape(nextRelease.replaceAll('-', '/'))}</time></p>`;
  if (!issue.questions.length && issues.length === 1) {
    return '<p class="activity-empty">第一批提問正在收集中。送出問題時勾選分享，就能把你的問法收進這一期。</p>' + publicationDate;
  }
  const period = displayRange(issue.start, issue.end);
  const choices = issues.length > 1 ? `<label class="issue-picker">期別
    <select data-issue>${issues.map(row =>
      `<option value="${escape(row.start)}" ${row.start === issue.start ? 'selected' : ''}>${escape(displayRange(row.start, row.end))}</option>`
    ).join('')}</select></label>` : `<span class="issue-period">${escape(period)}</span>`;
  const entries = issue.questions;
  let questions = '<p class="activity-empty">這一期沒有收到同事分享的提問。</p>';
  if (entries.length) {
    questions = `<ul class="real-questions">${entries.slice(0, 3).map(sharedQuestion).join('')}</ul>`;
    if (entries.length > 3) questions += `<details class="issue-more"><summary>其餘 ${entries.length - 3} 個提問</summary><ul class="real-questions">${entries.slice(3).map(sharedQuestion).join('')}</ul></details>`;
  }
  return choices + questions + publicationDate;
}

export function activitySections() {
  return `<div class="activity-columns" id="activity">
    <section class="activity-section" aria-labelledby="popular-title"><header><h2 id="popular-title"><span lang="en">Popular on</span> 客戶對話室</h2><p>近 14 天，同事最常提問的主題。</p></header>
      <div data-popular aria-live="polite"><p class="activity-empty">正在讀取提問排行…</p></div></section>
    <section class="activity-section" aria-labelledby="issue-title"><header><h2 id="issue-title">這裡有真實的疑問</h2><p>同事親自寫下、選擇分享的提問，每兩週刊出一期。</p></header>
      <div data-digest aria-live="polite"><p class="activity-empty">正在讀取雙週提問…</p></div></section></div>`;
}

export function mountActivity(host, findCard) {
  let request = 0;
  let issueStart = '';

  async function refresh() {
    const sequence = ++request;
    const query = issueStart ? '?issue=' + encodeURIComponent(issueStart) : '';
    const popular = host.querySelector('[data-popular]');
    const collection = host.querySelector('[data-digest]');
    popular.setAttribute('aria-busy', 'true');
    collection.setAttribute('aria-busy', 'true');
    try {
      const response = await fetch(endpoint + query, { cache: 'no-store', signal: AbortSignal.timeout(10000) });
      if (!response.ok) throw Error(String(response.status));
      const data = await response.json();
      if (!host.isConnected || sequence !== request) return;
      const restoreSelector = host.querySelector('[data-issue]') === document.activeElement;
      popular.innerHTML = ranking(data.popular, findCard);
      collection.innerHTML = digest(data);
      if (restoreSelector) host.querySelector('[data-issue]')?.focus({ preventScroll: true });
    } catch {
      if (!host.isConnected || sequence !== request) return;
      popular.innerHTML = '<p class="activity-empty">目前無法讀取排行。</p><button class="textbtn" type="button" data-activity-retry>重新讀取</button>';
      collection.innerHTML = '<p class="activity-empty">目前無法讀取雙週提問。</p>';
    } finally {
      if (sequence === request) {
        popular.removeAttribute('aria-busy');
        collection.removeAttribute('aria-busy');
      }
    }
  }

  host.addEventListener('change', event => {
    if (event.target.matches('[data-issue]')) {
      issueStart = event.target.value;
      refresh();
    }
  });
  host.addEventListener('click', event => {
    if (event.target.closest('[data-activity-retry]')) refresh();
  });
  refresh();
  return refresh;
}

export async function recordActivity(event) {
  const response = await fetch(endpoint, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(event), keepalive: true, signal: AbortSignal.timeout(10000)
  });
  if (!response.ok) throw Error(String(response.status));
  if (!(await response.json()).recorded) throw Error('Event not recorded');
}
