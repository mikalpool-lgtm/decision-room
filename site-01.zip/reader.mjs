const base=new URL('./vendor/pdfjs/',import.meta.url).href;
let libPromise;
function library(){
  if(!libPromise)libPromise=import(base+'pdf.min.mjs').then(lib=>{
    lib.GlobalWorkerOptions.workerSrc=base+'pdf.worker.min.mjs';
    return lib;
  });
  return libPromise;
}
const byRole=(host,role)=>host.querySelector('[data-reader="'+role+'"]');
export class ArticleReader {
  constructor(host,article,start,onClose,{onPage,modal=false}={}){
    this.host=host;this.article=article;this.onClose=onClose;this.onPage=onPage;
    this.pdfUrl=new URL('./pdf/'+article.id+'.pdf',import.meta.url).href;
    this.page=Math.min(article.pages.length,Math.max(1,start||1));this.zoom=1;this.token=0;this.disposed=false;
    host.className='reader'+(modal?' mobile-open':'');
    host.setAttribute('aria-label','文章原文預覽');
    host.innerHTML='<div class="reader-heading"><div><span data-reader="chapter" class="chapter"></span><h2 data-reader="title"></h2></div><div class="reader-actions"><button data-reader="wide" aria-label="放大閱讀區" title="放大閱讀區">⛶</button><button data-reader="close" aria-label="關閉原文預覽" title="關閉原文預覽">×</button></div></div><div class="pager"><button data-reader="prev">上頁</button><span data-reader="page" aria-live="polite"></span><button data-reader="next">下頁</button></div><div data-reader="viewport" class="reader-scroll"><p data-reader="message" class="reader-msg" role="status">載入跨頁中…</p><canvas data-reader="canvas" aria-label="專刊原文跨頁"></canvas></div><div data-reader="text" class="transcript" hidden></div><div class="reader-links"><div><button data-reader="zoom" title="調整頁面縮放">放大文字</button> · <button data-reader="toggle">純文字</button></div><a data-reader="open" target="_blank" rel="noopener">開啟 PDF</a></div>';
    const get=r=>byRole(host,r);
    this.get=get;
    get('title').textContent=article.title;get('chapter').textContent=article.chapter;
    host.style.setProperty('--accent',({People:'#cadb7a',Model:'#ebc1bf',AI:'#8bcddc'})[article.chapter]||'#b0b7a0');
    get('close').onclick=onClose;
    get('prev').onclick=()=>this.go(this.page-1);
    get('next').onclick=()=>this.go(this.page+1);
    const narrow=matchMedia('(max-width:690px)');
    this.syncModal=()=>{
      const active=host.classList.contains('wide-reader')||(modal&&narrow.matches);
      host.setAttribute('role',active?'dialog':'complementary');
      if(active)host.setAttribute('aria-modal','true');else host.removeAttribute('aria-modal');
    };
    this.narrow=narrow;narrow.addEventListener('change',this.syncModal);this.syncModal();
    get('wide').onclick=()=>{const on=host.classList.toggle('wide-reader');get('wide').setAttribute('aria-label',on?'縮回閱讀區':'放大閱讀區');this.syncModal();this.paint()};
    get('zoom').onclick=()=>{this.zoom=this.zoom===1?2:1;get('zoom').textContent=this.zoom===1?'放大文字':'符合寬度';this.paint()};
    get('toggle').onclick=()=>{const show=get('text').hidden;get('text').hidden=!show;get('viewport').hidden=show;get('zoom').disabled=show;get('toggle').textContent=show?'看跨頁':'純文字';if(!show)this.paint()};
    this.escape=e=>{
      if(document.querySelector('dialog[open]'))return;
      if(e.key==='Escape'){if(host.classList.contains('wide-reader'))get('wide').click();else onClose()}
      if(e.key!=='Tab'||!host.hasAttribute('aria-modal'))return;
      const items=[...host.querySelectorAll('button:not(:disabled),a[href]')].filter(el=>el.getClientRects().length);
      const first=items[0],last=items.at(-1);
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}
      if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}
    };
    document.addEventListener('keydown',this.escape);
    this.observer=new ResizeObserver(entries=>{const width=entries[0].contentRect.width;if(Math.abs(width-(this.lastWidth||0))>1){this.lastWidth=width;clearTimeout(this.timer);this.timer=setTimeout(()=>this.paint(),90)}});
    this.observer.observe(get('viewport'));this.go(this.page);
    this.load();
  }
  async load(){
    try{const lib=await library();if(this.disposed)return;
      this.loading=lib.getDocument({url:this.pdfUrl,cMapUrl:base+'cmaps/',cMapPacked:true,standardFontDataUrl:base+'standard_fonts/',wasmUrl:base+'wasm/',isEvalSupported:false});
      this.doc=await this.loading.promise;if(!this.disposed)await this.paint();
    }catch{if(!this.disposed)this.fallback()}
  }
  go(n){if(n<1||n>this.article.pages.length)return;this.page=n;const p=this.article.pages[n-1],g=this.get;
    g('canvas').hidden=true;g('message').hidden=false;g('message').textContent=this.failed?'可切換純文字，或開啟這一頁的 PDF。':'載入跨頁中…';
    g('page').textContent=p.label+' · '+n+'/'+this.article.pages.length;
    g('prev').disabled=n===1;g('next').disabled=n===this.article.pages.length;
    g('text').textContent=p.text;g('open').href=this.pdfUrl+'#page='+n;
    this.onPage?.(n);this.paint();
  }
  async paint(){
    if(this.disposed||!this.doc||this.get('viewport').hidden)return;
    const id=++this.token;this.task?.cancel();
    try{const p=await this.doc.getPage(this.page);if(id!==this.token||this.disposed)return;
      const g=this.get,w=g('viewport').clientWidth;if(!w)return;
      const natural=p.getViewport({scale:1});const width=Math.max(140,(w-12)*this.zoom);
      const css=p.getViewport({scale:width/natural.width});
      const dpr=Math.min(window.devicePixelRatio||1,2,2800/css.width);
      const view=p.getViewport({scale:width*dpr/natural.width});
      const canvas=document.createElement('canvas');canvas.width=Math.ceil(view.width);canvas.height=Math.ceil(view.height);
      this.task=p.render({canvasContext:canvas.getContext('2d'),viewport:view});
      await this.task.promise;if(id!==this.token||this.disposed)return;
      canvas.dataset.reader='canvas';canvas.setAttribute('aria-label',this.article.title+'，'+this.article.pages[this.page-1].label);
      canvas.style.width=css.width+'px';canvas.style.height=css.height+'px';g('canvas').replaceWith(canvas);g('message').hidden=true;
    }catch(e){if(!this.disposed&&id===this.token&&e.name!=='RenderingCancelledException')this.fallback()}
  }
  fallback(){this.failed=true;const g=this.get;g('message').hidden=false;g('message').textContent='此瀏覽器未能繪製跨頁。可切換純文字，或點「開啟 PDF」查看這一頁。';g('canvas').hidden=true}
  destroy(){this.disposed=true;this.token++;this.task?.cancel();this.observer.disconnect();this.narrow.removeEventListener('change',this.syncModal);clearTimeout(this.timer);document.removeEventListener('keydown',this.escape);this.loading?.destroy()?.catch(()=>{});}
}
