import {createActorStage} from './actor-stage.mjs';

const stage = document.getElementById('actor-stage');
const renderActor = createActorStage(stage);
const play = document.getElementById('popup-play');
const playLabel = document.getElementById('popup-play-label');
const slider = document.getElementById('popup-time');
const clock = document.getElementById('popup-clock');
const heading = document.getElementById('popup-title');
const caption = document.getElementById('popup-caption');
const controls = [...document.querySelectorAll('[data-beat]')];
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const seconds = Number(slider.max);
const beats = [
  {title:['每年一本，','今年怎麼用？'], text:'又到了《決策智慧》出版的時候。去年的那一本，還在我桌上。', alt:'戴圓眼鏡的女生靠在一疊年度專刊旁。'},
  {title:['競品做了，','我們要跟嗎？'], text:'客戶突然打來。嗯……這題怎麼回答比較好？', alt:'短髮同事一手拿著話筒，另一隻手掌心朝上。'},
  {title:['是哪一篇？','第幾頁？'], text:'明天就要提案了。我記得專刊好像寫過，到底在哪裡？', alt:'捲髮同事拿著放大鏡，面前是貼滿書籤的文章。'},
  {title:['從你手上的','問題開始。'], text:'把客戶的原話寫下來，就能找到書裡相關的觀點、數據與案例。', alt:'綁馬尾的同事坐在攤開的書前，望向問題卡。'},
  {title:['把這一頁，','帶進提案。'], text:'會前找個話題，提案找個依據。遇到新需求，也看看其他團隊能怎麼幫忙。', alt:'銀髮講者手持筆，站在提案圖表旁。'},
  {title:['所以，今天','你想找什麼？'], text:'想一想，剛剛客戶怎麼說？從那句話開始聊。', alt:'留鬍子的同事與客戶隔桌交談。'}
];
const sceneSeconds = seconds / beats.length;
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
let elapsed = 0;
let playing = !reduced.matches;
let chapter = -1;
let frame = 0;
let last = null;

function labelButton() {
  const mode = playing ? 'pause' : elapsed >= seconds ? 'replay' : 'play';
  const label = {pause:'暫停', replay:'重播', play:'播放'}[mode];
  if (play.dataset.mode === mode) return;
  play.dataset.mode = mode;
  playLabel.textContent = label;
  play.setAttribute('aria-label', label+'開場');
}

function draw() {
  const p = elapsed / seconds;
  const next = Math.min(Math.floor(elapsed / sceneSeconds), beats.length - 1);
  renderActor(next, (elapsed - next * sceneSeconds) / sceneSeconds);
  slider.value = String(elapsed);
  slider.style.setProperty('--played', (100*p)+'%');
  const whole = Math.floor(elapsed);
  const readout = '0:'+String(whole).padStart(2,'0');
  if (clock.textContent !== readout) {
    clock.textContent = readout;
    slider.setAttribute('aria-valuetext',whole+' 秒，共 '+seconds+' 秒');
  }
  if (chapter !== next) {
    chapter = next;
    const beat = beats[chapter];
    heading.querySelector('span').textContent = beat.title[0];
    heading.querySelector('em').textContent = beat.title[1];
    caption.textContent = beat.text;
    stage.setAttribute('aria-label',beat.alt);
    document.getElementById('actor-count').textContent=String(next+1).padStart(2,'0')+' / 06';
    document.getElementById('actor-voice').textContent=next<3?'同事的心聲':'對話室的回應';
    controls.forEach((button,i)=>{
      if(i === chapter) button.setAttribute('aria-current','step');
      else button.removeAttribute('aria-current');
    });
  }
  labelButton();
}

function tick(now) {
  frame = 0;
  if (last !== null && now - last < 1000/30) {
    frame = requestAnimationFrame(tick);
    return;
  }
  if (last !== null) elapsed = Math.min(seconds, elapsed + (now - last)/1000);
  last = now;
  if (elapsed >= seconds) playing = false;
  draw();
  if (playing) frame = requestAnimationFrame(tick);
}

function schedule() {
  cancelAnimationFrame(frame);
  frame = 0;
  last = null;
  if (playing && !document.hidden) frame = requestAnimationFrame(tick);
}

function seek(t) {
  playing = false;
  elapsed = clamp(t, 0, seconds);
  schedule();
  draw();
}
play.addEventListener('click',()=>{
  if (!playing && elapsed >= seconds) elapsed = 0;
  playing = !playing;
  schedule();
  draw();
});
slider.addEventListener('input',()=>seek(Number(slider.value)));
controls.forEach((button,i)=>button.addEventListener('click',()=>{
  if (!playing) { seek(i * sceneSeconds); return; }
  elapsed = i * sceneSeconds;
  schedule();
  draw();
}));
document.addEventListener('visibilitychange',schedule);
window.addEventListener('pageshow',schedule);
window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame); last=null;});
reduced.addEventListener('change',()=>{if(reduced.matches) seek(elapsed);});
draw();
schedule();
