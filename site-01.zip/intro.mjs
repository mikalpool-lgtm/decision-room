const seenKey = 'decision-room:intro-seen:v1';
const durations = [3700, 4200, 3600, 4200, 4800, 3500];

function alreadySeen() {
  try {
    return sessionStorage.getItem(seenKey) === '1';
  } catch {
    return Boolean(history.state?.[seenKey]);
  }
}

function markSeen() {
  try {
    sessionStorage.setItem(seenKey, '1');
  } catch {
    // Keep refresh from reopening the film if tab storage is unavailable.
    try { history.replaceState({ ...history.state, [seenKey]: true }, ''); } catch {}
  }
}

async function loadArt(scene) {
  await Promise.all(Array.from(scene.querySelectorAll('img'), async image => {
    image.loading = 'eager';
    if (image.dataset.src && !image.hasAttribute('src')) image.src = image.dataset.src;
    if (!image.hasAttribute('src')) return;
    try { await image.decode(); } catch { /* The captions and controls remain usable. */ }
  }));
}

export function setupIntro(onReturn) {
  const dialog = document.getElementById('story-intro');
  if (!dialog || typeof dialog.showModal !== 'function') return;
  const scenes = [...dialog.querySelectorAll('[data-intro-scene]')];
  const segments = [...dialog.querySelectorAll('[data-intro-progress] i')];
  if (scenes.length !== durations.length || segments.length !== scenes.length) return;

  const skip = dialog.querySelector('[data-intro-skip]');
  const pause = dialog.querySelector('[data-intro-pause]');
  const prev = dialog.querySelector('[data-intro-prev]');
  const next = dialog.querySelector('[data-intro-next]');
  const count = dialog.querySelector('[data-intro-count]');
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  let index = 0;
  let revision = 0;
  let source = '';
  let paused = false;
  let ready = false;
  let elapsed = 0;
  let started = null;
  let frame = 0;

  function stopClock() {
    if (started !== null) elapsed += Math.max(0, performance.now() - started);
    started = null;
    cancelAnimationFrame(frame);
    frame = 0;
  }

  function close(reason) {
    if (!dialog.open) return;
    revision++;
    stopClock();
    dialog.close();
    if (reason === 'navigation') return;
    if (location.hash === '#intro') history.replaceState(history.state, '', '#home');
    // A replay from another part of the site returns to that same context.
    onReturn(source !== 'replay' || reason === 'end');
  }

  function advance() {
    if (index === scenes.length - 1) close('end');
    else showScene(index + 1);
  }

  function tick(now) {
    const amount = Math.min(1, (elapsed + Math.max(0, now - started)) / durations[index]);
    segments[index].style.setProperty('--progress', String(amount));
    if (amount === 1) advance();
    else frame = requestAnimationFrame(tick);
  }

  function syncClock() {
    stopClock();
    const playing = dialog.open && ready && !paused && !document.hidden && !motion.matches;
    dialog.dataset.paused = String(!playing);
    pause.hidden = motion.matches;
    pause.textContent = paused ? '繼續' : '暫停';
    pause.setAttribute('aria-label', paused ? '繼續播放開場' : '暫停播放開場');
    if (playing) {
      started = performance.now();
      frame = requestAnimationFrame(tick);
    }
  }

  async function showScene(number) {
    const current = ++revision;
    stopClock();
    index = number;
    elapsed = 0;
    ready = false;
    scenes.forEach((scene, i) => { scene.hidden = i !== index; });
    segments.forEach((segment, i) => {
      segment.dataset.state = i < index ? 'done' : i === index ? 'current' : 'upcoming';
      segment.style.setProperty('--progress', i < index ? '1' : '0');
    });
    dialog.dataset.scene = String(index + 1);
    count.textContent = String(index + 1).padStart(2, '0') + ' / ' + String(scenes.length).padStart(2, '0');
    prev.disabled = index === 0;
    next.textContent = index === scenes.length - 1 ? '進入網站' : '下一幕';
    syncClock();
    await loadArt(scenes[index]);
    if (revision !== current || !dialog.open) return;
    ready = true;
    syncClock();
    if (scenes[index + 1]) void loadArt(scenes[index + 1]);
  }

  function open(mode) {
    if (dialog.open) return;
    source = mode;
    paused = false;
    dialog.showModal();
    markSeen();
    void showScene(0);
    skip.focus({ preventScroll: true });
  }

  skip.addEventListener('click', () => close('skip'));
  pause.addEventListener('click', () => { paused = !paused; syncClock(); });
  prev.addEventListener('click', () => { if (index > 0) void showScene(index - 1); });
  next.addEventListener('click', advance);
  dialog.addEventListener('cancel', event => { event.preventDefault(); close('skip'); });
  motion.addEventListener('change', syncClock);
  document.addEventListener('visibilitychange', syncClock);
  document.querySelector('[data-open-intro]')?.addEventListener('click', () => open('replay'));
  window.addEventListener('hashchange', () => {
    if (location.hash === '#intro') open('direct');
    else close('navigation');
  });

  if (location.hash === '#intro') open('direct');
  else if ((!location.hash || location.hash === '#home') && !motion.matches && !alreadySeen()) open('auto');
}
