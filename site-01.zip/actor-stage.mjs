import firstPair from './actor-cut-12.mjs';
import middlePair from './actor-cut-34.mjs';
import finalPair from './actor-cut-56.mjs';

const outlines = [...firstPair, ...middlePair, ...finalPair];
const drawingSize = 512;

function surface() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = drawingSize;
  return canvas;
}

function separateDrawing(image, outline) {
  const silhouette = new Path2D(outline.body);
  const body = surface();
  const ink = body.getContext('2d', {willReadFrequently:true});
  ink.save();
  ink.clip(silhouette);
  ink.drawImage(image, 0, 0);
  ink.restore();

  // Transparent paper keeps a moving margin from painting over the scenery.
  const pixels = ink.getImageData(0, 0, drawingSize, drawingSize);
  const rgba = pixels.data;
  for (let i = 0; i < rgba.length; i += 4) {
    if (!rgba[i+3]) continue;
    const paper = Math.min(rgba[i], rgba[i+1], rgba[i+2]);
    const density = 255 - paper;
    rgba[i+3] *= density / 255;
    if (!density) continue;
    for (let channel = 0; channel < 3; channel++) {
      rgba[i+channel] = (rgba[i+channel] - paper) * 255 / density;
    }
  }
  ink.putImageData(pixels, 0, 0);

  const back = surface();
  const background = back.getContext('2d');
  background.drawImage(image, 0, 0);
  background.fillStyle = '#fff';
  background.fill(silhouette);

  let front = null;
  if (outline.front) {
    const mask = new Path2D(outline.front);
    front = surface();
    const foreground = front.getContext('2d');
    foreground.clip(mask);
    foreground.drawImage(image, 0, 0);
    ink.globalCompositeOperation = 'destination-out';
    ink.fill(mask);
  }
  return {body, back, front};
}

export function createActorStage(stage) {
  const canvas = stage.querySelector('canvas');
  const poster = stage.querySelector('img');
  const ctx = canvas.getContext('2d', {alpha:false});
  let active = 0;
  let phase = 0;
  const frames = outlines.map((outline, index) => {
    const image = new Image();
    const frame = {image, outline, layers:null};
    image.addEventListener('load', () => {
      if (ctx) frame.layers = separateDrawing(image, outline);
      if (index === active) paint();
    }, {once:true});
    image.src = './assets/intro/scene-' + (index + 1) + '.webp';
    return frame;
  });

  function paint() {
    const {image, outline, layers} = frames[active];
    if (!ctx || !layers) {
      canvas.hidden = true;
      poster.hidden = false;
      return;
    }
    const unit = canvas.width / drawingSize;
    ctx.setTransform(unit, 0, 0, unit, 0, 0);
    const sway = Math.sin(phase * 2 * Math.PI);
    if (Math.abs(sway) < .0001) {
      ctx.drawImage(image, 0, 0);
    } else {
      ctx.drawImage(layers.back, 0, 0);
      const [px, py] = outline.pivot;
      ctx.save();
      ctx.translate(px + .8 * sway, py);
      ctx.rotate(.55 * Math.PI / 180 * sway);
      ctx.drawImage(layers.body, -px, -py);
      ctx.restore();
      if (layers.front) ctx.drawImage(layers.front, 0, 0);
    }
    canvas.hidden = false;
    poster.hidden = true;
  }

  function resize() {
    const px = Math.max(1, Math.min(1120, Math.round(stage.clientWidth * Math.min(devicePixelRatio || 1, 2))));
    if (canvas.width !== px || canvas.height !== px) canvas.width = canvas.height = px;
    paint();
  }
  new ResizeObserver(resize).observe(stage);
  resize();
  return (scene, t) => {
    if (active !== scene) {
      active = scene;
      poster.src = frames[scene].image.src;
    }
    phase = t;
    paint();
  };
}
