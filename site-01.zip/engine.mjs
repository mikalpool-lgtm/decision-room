const fold = value => String(value ?? '').normalize('NFKC').toLowerCase();
const compact = value => fold(value).replace(/[^\p{L}\p{N}]/gu, '');
const common = new Set('客戶 消費 客人 我們 他們 這個 怎麼 如何 可以 是否 什麼 問題 需要 應該 想要 請問 一個 現在 但是 然後 如果 因為 沒有 最近 專刊 提問 建議 到底 真的 有沒有 怎麼辦 哪些 怎樣 不能'.split(' '));
const broadTerms = new Set(['ai','品牌','行銷','客戶','顧客','公司','數據','團隊','企業','我們','消費者','市場','問題','媒體','產品','廣告']);
const aliases = [
  [/社群媒體|social\s*media/gi,'社群'], [/代理人|智能體|智慧代理/g,' agent '],
  [/roas|廣告支出報酬/gi,' roas 廣告增量'], [/品牌想不起來|記不住|記不得|想不起來/g,'記憶'],
  [/(?:記不起|想不起|忘了)(?:是)?(?:哪個|哪家)?(?:牌子|品牌)/g,'曝光 品牌記憶'],
  [/成交|下單/g,'轉換'], [/帶來訂單|帶單/g,'帶單 轉單'], [/營業額/g,'營收'],
  [/砍掉|砍預算|刪預算|縮減預算|削減預算/g,'刪減預算'],
  [/不知道.{0,4}(從哪|怎麼開始)|從何入手|從哪(裡|邊)?(著手|開始)|第一步/g,'試點 開始'],
  [/網紅|influencer/gi,'kol'], [/ai\s*搜尋|生成式搜尋/gi,'geo ai搜尋'],
  [/人工智慧/gi,'ai'], [/綫上|線上/g,'線上'], [/不敢用|沒人用/g,'採用 組織'],
  [/catch[ -]?up/gi,'近況'], [/模擬消費者|虛擬消費者|合成受眾/g,'people model 模擬'],
];

function searchable(input) {
  let text = fold(input);
  for (const [pattern,replacement] of aliases) text = text.replace(pattern, match => match + ' ' + replacement);
  return text;
}

function terms(input) {
  const tokens = new Set();
  for (const match of searchable(input).matchAll(/[a-z0-9]+|[\p{Script=Han}]+/gu)) {
    const word = match[0];
    if (/^[a-z0-9]/.test(word)) { if (word.length > 1) tokens.add(word); continue; }
    for (let i = 0; i + 1 < word.length; i++) {
      const term = word.slice(i,i+2);
      if (!common.has(term)) tokens.add(term);
    }
  }
  return tokens;
}

const indexes = new WeakMap();
function indexCards(cards) {
  if (indexes.has(cards)) return indexes.get(cards);
  const counts = new Map();
  const rows = cards.map(card => {
    const keywords = (card.keywords ?? []).map(compact).filter(w => w.length > 1);
    const title = terms(card.question);
    const all = terms([card.question,...(card.keywords ?? [])].join(' '));
    for (const word of all) counts.set(word,1 + (counts.get(word) || 0));
    return {card,title,keywords,all};
  });
  const index = {rows,counts};
  indexes.set(cards,index);
  return index;
}

function rankCards(question,cards) {
  const {rows,counts} = indexCards(cards);
  const query = terms(question);
  const joined = compact(searchable(question));
  return rows.map(({card,title,keywords,all}) => {
    let score = 0, signals = 0;
    for (const word of query) {
      if (!all.has(word)) continue;
      const idf = Math.log(1 + cards.length / counts.get(word));
      score += idf * (title.has(word) ? 1.5 : 1) * (broadTerms.has(word) ? .18 : 1);
      if (!broadTerms.has(word) && counts.get(word) <= cards.length*.55) signals++;
    }
    const exact = keywords.filter(word => joined.includes(word) && !broadTerms.has(word) && !common.has(word));
    for (const word of exact) score += 2 + Math.min(4,word.length*.65);
    if (compact(question) === compact(card.question)) score += 50;
    return {card,score,signals,exact};
  }).sort((a,b) => b.score - a.score);
}

const pagesCache = new WeakMap();
function articlePages(article) {
  if (!pagesCache.has(article)) {
    pagesCache.set(article,(article.pages ?? []).map(page => ({page,text:compact(page.text)})));
  }
  return pagesCache.get(article);
}

/** Resolve only an anchor uniquely located in the specified article to a PDF page. */
export function resolveReferences(card,sources) {
  const refs = [];
  for (const citation of card.sources || []) {
    const article = sources.find(item => item.id === citation.id);
    if (!article) continue;
    const needle = compact(citation.anchor);
    const matches = needle.length >= 3 ? articlePages(article).filter(row => row.text.includes(needle)) : [];
    const page = matches.length === 1 ? matches[0].page : null;
    if (refs.some(ref => ref.id === article.id && ref.page === (page?.page ?? null))) continue;
    refs.push({id:article.id,title:article.title,chapter:article.chapter,page:page?.page ?? null,
      label:page?.label || '文章全文',anchor:page ? citation.anchor : ''});
  }
  return refs;
}

const generic = /^(嗨|您好|你好|哈囉|hi|hello|近況|catchup|想聊聊|聊聊|ai|人工智慧|行銷|媒體|品牌|幫我|最近有什麼|有什麼話題)$/i;
const followupIntents = [
  ['limit',/限制|可信|證據強|適用範圍|能保證|有多可靠|有哪些盲點|要留意什麼/],
  ['evidence',/案例|例子|舉例|原文|哪一頁|出處|依據|有數據|看證據|看文章|證據呢/],
  ['short',/一句話|短一點|簡短|簡單說|精簡|怎麼開口|怎麼接話|怎麼回(覆|答)?/],
  ['next',/下一步|然後呢|接下來|怎麼追問|怎麼做|怎麼落地|如何開始|先做什麼|具體一點|繼續|再說一些|多說一點|還有呢/],
];

function suggested(cards,ids) {
  return ids.filter(id => cards.some(card => card.id === id));
}
function clarification(kind,cards,rank=[]) {
  const selected = rank.filter(item => item.signals > 0).slice(0,3).map(item => item.card.id);
  return {kind,cardId:null,refs:[],limit:'',insight:'',ask:[],
    reply:kind === 'clarify'
      ? '這次碰面，客戶最想決定哪件事？可以貼一句原話，例如「社群帶單少，明年要不要減預算？」或「團隊想用 AI，第一個試點怎麼選？」'
      : '這個問題在目前的專刊對談題庫裡還找不到足夠依據。可以補上客戶要做的決定，以及他正在衡量的兩個選項。',
    related:selected.length ? selected : suggested(cards,['p09','p20','p02'])};
}

function cardTurn(card,sources,mode) {
  const refs=resolveReferences(card,sources);
  const turn={cardId:card.id,kind:mode ? 'followup' : 'answer',reply:card.reply,ask:[...card.ask],
    insight:card.insight,limit:card.limit,refs,related:[...(card.related??[])]};
  if (mode === 'evidence') {
    turn.reply = card.insight;
    turn.insight = refs.length ? '會議中可以點開下方原文，和客戶一起確認案例的情境與適用條件。' : '';
  } else if (mode === 'limit') {
    turn.reply = card.limit;
    turn.limit = '';
  } else if (mode === 'short') {
    turn.reply = card.reply.match(/^.*?[。？！]/u)?.[0] || card.reply;
    turn.insight = '';
    turn.ask = card.ask.slice(0,1);
  } else if (mode === 'next') {
    turn.reply = '先用這個問題接下去：「' + card.ask[0] + '」等客戶說出最近一次的例子，再一起確認當時要做的決定，以及還缺哪個依據。';
    turn.ask = card.ask.slice(1);
  }
  return turn;
}

export function resolveTurn(question,history=[],cards=[],sources=[],options={}) {
  const value = typeof question === 'string' ? question.trim().slice(0,2000) : '';
  const target = options.cardId && cards.find(card => card.id === options.cardId);
  if (target) return cardTurn(target,sources);
  const last = history.at(-1);
  const previous = cards.find(card => card.id === last?.cardId);
  const ranked = value ? rankCards(value,cards) : [];
  const best = ranked[0];
  const mode = followupIntents.find(([,pattern]) => pattern.test(value))?.[0];
  const strongMatch = best && best.score >= 4.8 && (best.exact.length || best.signals >= 2);
  if (previous && mode && value.length < 65 &&
      (!strongMatch || previous.id === best.card.id || value.length <= 9 && !best.exact.length)) {
    return cardTurn(previous,sources,mode);
  }
  if (!value || generic.test(compact(value)) || /聊聊近況|不知道(要)?聊什麼|有什麼可以聊/.test(value)) return clarification('clarify',cards);
  if (strongMatch) return cardTurn(best.card,sources,mode && previous?.id === best.card.id ? mode : null);
  if (previous && /^(再來|還有|好啊|然後|是的|對|好)[呢嗎呀？?。！!\s]*$/u.test(value)) return cardTurn(previous,sources,'next');
  return clarification('unsupported',cards,ranked);
}
